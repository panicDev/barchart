package id.paniclabs.barchart.label

import android.view.View

interface Label {

    fun render(view: View)
}