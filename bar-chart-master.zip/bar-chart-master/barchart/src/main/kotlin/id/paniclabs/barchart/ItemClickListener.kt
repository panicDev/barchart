package id.paniclabs.barchart


/**
 * @author   panicDev
 * @email    panic.inc.dev@gmail.com
 * @project  bar-chart
 * @since    3/12/19.
 */
interface ItemClickListener {
    fun onItemClick(item: ChartItem)
    fun onItemLongClick(item: ChartItem)
}